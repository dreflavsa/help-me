import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
    plugins: [
        react(),
        tailwindcss(),
        VitePWA({
            registerType: "autoUpdate",
            includeAssets: ["favicon.svg", "logo.svg", "apple-touch-icon.png"],
            manifest: {
                name: "HELP ME",
                short_name: "HELP ME",
                description: "Correction de devoirs par IA pour étudiants.",
                theme_color: "#6B4A87",
                background_color: "#F2EEF7",
                display: "standalone",
                orientation: "portrait",
                start_url: "/",
                scope: "/",
                icons: [
                    { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
                    { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
                    { src: "/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
                ],
            },
            workbox: {
                // Les appels /api ne passent jamais par le cache — voir
                // l'explication plus haut.
                navigateFallbackDenylist: [/^\/api/],
                runtimeCaching: [
                    {
                        urlPattern: ({ url }) => url.pathname.startsWith("/api"),
                        handler: "NetworkOnly",
                    },
                ],
            },
        }),
    ],
});